#include "pms7003.h"
#include "esp_log.h"
#include "string.h"

static const char *TAG = "PMS7003";

esp_err_t pms7003_init(void)
{
    const uart_config_t uart_config = {
        .baud_rate = PMS_UART_BAUD,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };

    // Configure UART parameters
    esp_err_t err = uart_param_config(PMS_UART_PORT, &uart_config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "UART param config failed: %s", esp_err_to_name(err));
        return err;
    }

    // Set UART pins
    err = uart_set_pin(PMS_UART_PORT, PMS_TX_GPIO, PMS_RX_GPIO, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "UART set pin failed: %s", esp_err_to_name(err));
        return err;
    }

    // Install UART driver with buffer
    err = uart_driver_install(PMS_UART_PORT, PMS_BUF_SIZE * 2, 0, 0, NULL, 0);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "UART driver install failed: %s", esp_err_to_name(err));
        return err;
    }

    ESP_LOGI(TAG, "UART connection initialized successfully (TX: GPIO%d, RX: GPIO%d, Baud: %d)", 
             PMS_TX_GPIO, PMS_RX_GPIO, PMS_UART_BAUD);
    return ESP_OK;
}

esp_err_t pms7003_read(pms7003_data_t *data)
{
    if (data == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t len = 0;
    uart_get_buffered_data_len(PMS_UART_PORT, &len);
    if (len < 32) {
        return ESP_ERR_NOT_FOUND;
    }

    // Read bytes from UART
    static uint8_t buf[PMS_BUF_SIZE];
    int read_len = uart_read_bytes(PMS_UART_PORT, buf, (len > PMS_BUF_SIZE) ? PMS_BUF_SIZE : len, 0);
    if (read_len < 32) {
        return ESP_ERR_NOT_FOUND;
    }

    // Search backward to find the latest valid frame
    // A frame starts with 0x42, 0x4D, and has 32 bytes.
    // So the start index must be at most read_len - 32.
    for (int i = read_len - 32; i >= 0; i--) {
        if (buf[i] == 0x42 && buf[i + 1] == 0x4D) {
            // Check frame length (must be 28, bytes 2 and 3 = 0x00, 0x1C)
            uint16_t frame_len = (buf[i + 2] << 8) | buf[i + 3];
            if (frame_len == 28) {
                // Verify checksum
                uint16_t checksum = (buf[i + 30] << 8) | buf[i + 31];
                uint16_t calc_checksum = 0;
                for (int j = 0; j < 30; j++) {
                    calc_checksum += buf[i + j];
                }
                if (checksum == calc_checksum) {
                    // Valid frame found! Parse data:
                    data->pm1_0_std = (buf[i + 4] << 8) | buf[i + 5];
                    data->pm2_5_std = (buf[i + 6] << 8) | buf[i + 7];
                    data->pm10_std  = (buf[i + 8] << 8) | buf[i + 9];
                    data->pm1_0_atm = (buf[i + 10] << 8) | buf[i + 11];
                    data->pm2_5_atm = (buf[i + 12] << 8) | buf[i + 13];
                    data->pm10_atm  = (buf[i + 14] << 8) | buf[i + 15];
                    return ESP_OK;
                }
            }
        }
    }

    return ESP_ERR_NOT_FOUND;
}
